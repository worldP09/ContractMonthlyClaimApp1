﻿namespace CMCS.ViewModels
{
    public class HomeViewModel
    {
        public string WelcomeMessage { get; set; }
    }
}